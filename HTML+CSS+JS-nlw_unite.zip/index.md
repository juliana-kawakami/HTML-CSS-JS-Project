```js
const mensagem = "Oi, tudo bem?"

// alert(mensagem)

//array
let participantes = [
  {
    nome: "Maryk Brito",
    email: "mayk@gmail.com",
    dataInscricao: new Date(2024, 2, 22, 19, 20),
    dataCheckIn: new Date(2024, 2, 25, 22, 0)
  }
]

//for
for(let participante of participantes){
    //faca algo
    //enquanto tiver participantes nessa lista
}

